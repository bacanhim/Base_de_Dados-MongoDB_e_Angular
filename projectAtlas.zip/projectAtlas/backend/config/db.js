var mongoose = require('mongoose');
var connection = mongoose.connect('');
module.exports = connection;