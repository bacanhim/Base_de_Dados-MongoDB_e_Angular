var express = require('express'),
    router = express.Router(),
    pessoa = require('../models/pessoa.js'),
    mongoose = require('mongoose');
router.get('/', function (req, res) {
    pessoa.find({}, function (err, data) {
        if (err) {
            res.send('error');
            return;
        }
        res.send(data);
    });
});
router.post("/",function (req, res) {
    var obj = req.body;
    var model = new pessoa(obj);
    model.save(function (err) {
        if (err) {
            res.send("error");
            return;
        }
        res.send("created");
    })
});
module.exports = router;
